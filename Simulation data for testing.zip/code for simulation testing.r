#################################################################################
# Processed data 1 - user ID - Sub categories.txt
# Processed_original_data.csv
# Processed data 2 - user ID Categories.csv
# Categories.csv
#################################################################################
setwd("C:\\Users\\Nikhil\\Downloads\\ALDA\\project\\sim\\")

library(fpc)
library(mclust)
library(kknn)
library(flexclust)
library(cluster)
library(class)
library(rpart)
library(lsa)
library(plyr)



preprocessOriginalData <- function(){
  #########################################################################################################
  # load original check in data to find frequencies of each venue
  #########################################################################################################
  
  #load original data
  originalData <- read.csv("Processed_original_data.csv",head=TRUE)
  names(originalData) <- c("UserID","VenueID","VenueCategoryID","Subcategory","Category")
  #View(originalData)
  return(originalData)
}

preprocessFrequencies <- function(originalData){
  # sorting venues according to frequencies
  frequencies <- table(originalData$VenueID)
  #View(frequencies)
  frequencies <-as.data.frame(frequencies)
  frequencies<-frequencies[order(-frequencies$Freq),]
  return(frequencies)
}

obtainClusters <- function(){
  #########################################################################################################
  # Pre-processing, separating training and test data, clustering, building model using training data
  # and predicting class labels for test data
  #########################################################################################################
  
  #load the data (had user ID and 9 sub categories)
  grouped_data <- read.table("Processed data 2 - user ID Categories.csv",sep=",",head=TRUE)
  
  #NOTE: PREPROCESSING NOT DONE FOR SIMULATED DATA
  
  #preprocessing: To get better clusters, set value to 0 or 1 based on median value
  #for(j in 2:ncol(grouped_data))
  #{
  #  for (i in 1:nrow(grouped_data))
  #  {
  #    grouped_data[i,j] <- if(grouped_data[i,j] > mean(grouped_data[,j], trim = 0.1)) 1 else 0;
  #  }
  #}
  
  #extract last 13 users for testing and delete them from dataset
  test_data <- grouped_data[19,]
  training_data <- grouped_data[-19,]
  
  
  #kmeans clustering with 6 clusters
  #remove user ID column before running clustering algorithm
  kmeans_result <- kmeans(x = (training_data[,-c(1)]),centers = 6 )
  
  #add the class label to the grouped data to run a classification algorithm
  training_data$class <- as.factor(kmeans_result$cluster)
  
  #build a decision tree classifier
  class_tree <- rpart(training_data$class ~., data = training_data[,c(2:10)],
                      method = "class", parms = list(split='information'),
                      control = rpart.control(minsplit = 1, minbucket = 1, cp = 0))
  
  #predict a cluster for the 3 test points
  predicted_cluster <- predict(class_tree, test_data )
  classes <- apply(predicted_cluster, 1, which.max)
  return(list(grouped_data,training_data,classes))
}

findSimUser <- function(grouped_data, training_data, classes){
  #####################################################################################################
  # using sub category data finding similar user from users in the test user's predicted class
  # 
  #####################################################################################################
  
  
  #load the user dataset with the 251 attribs (sub category data)
  grouped_data_sub_cat <- read.table("Processed data 1 - user ID - Sub categories.txt",sep="\t",head=TRUE)
  
  #TODO: 
  #get the records of all users belonging to predicted cluster, and also the test user's record
  #use some distance metric and find a similar user (or few similar users?)
  #recommend place
  
  
  #extract last 13 users for testing and delete them from dataset
  test_data_sub_cat <- grouped_data_sub_cat[19,]
  grouped_data_sub_cat <- grouped_data_sub_cat[-19,]
  
  
  
  # data frame that holds similarities and similar users for test users
  cosineTop <- data.frame(numeric(0), numeric(0), numeric(0))
  colnames(cosineTop) <- c("SimUser","Sim","User")
  
  for (j in 1:nrow(test_data_sub_cat)){
    # subset of users in the same class/cluster
    groupedData_subset <- grouped_data[training_data$class==classes[j],1]
    groupedData_subset <- grouped_data_sub_cat[groupedData_subset,]
    
    # vector to hold similarities with all users
    a <- rep(NA, nrow(groupedData_subset))
    groupedData_subset
    
    for(i in 1:nrow(groupedData_subset)){
      a[i] <- cosine(unlist(groupedData_subset[i,-1]),unlist(test_data_sub_cat[j,-1]))
    }
    
    answer<-data.frame(groupedData_subset[,1],a)
    answer <- answer[order(-a),]
    answer <- answer[1:3,]
    answer$User <- j
    cosineTop <- rbind(cosineTop,answer)
  }
  return(cosineTop)
}



recommend <- function(userNum, originalData, cosineTop, frequencies, category) {
  ###############################################################################################
  # Identify top 3 similar users in predicted cluster/class
  # Identify top 3 venues which were visitedby similar users but not by test user
  # Recommend those
  ###############################################################################################
  #j <- 1
  #for(j in 1:13){
  j <- userNum
  # places visited by test user
  testUserData <- originalData[originalData$UserID==18+j & originalData$Category==category,]
  testUserData <- testUserData$VenueID
  testUserData <- unique(testUserData)
  #View(testUserData)
  # places visited by similar user
  similarUserData <- data.frame()
  for(i in 1:3){
    similarUserData2 <- originalData[originalData$UserID==cosineTop[3*(j-1)+i,1] & originalData$Category==category,]
    similarUserData2 <- similarUserData2$VenueID
    similarUserData <- rbind(similarUserData,as.data.frame(similarUserData2))
  }
  
  # keep only unique data
  #View(similarUserData2)
  similarUserData <- unique(similarUserData)
  #View(similarUserData)
  
  # venues where test user has not visited
  unvisited <- subset(similarUserData, !similarUserData2 %in% testUserData)
  unvisited <- frequencies[frequencies$Var1 %in% unvisited$similarUserData2,]
  View(frequencies)
  cat_subcat <- unique(originalData[,4:5])
  View(cat_subcat[cat_subcat$Category==category,])
  
  View(unique(cat_subcat$Category))
  
  unvisited <- unvisited[1:3,]
  
  # contains the three top recommendations
  return(unvisited)
  
  #}
}

originalData <- preprocessOriginalData()
frequencies <- preprocessFrequencies(originalData)
someList <- obtainClusters()
grouped_data <- as.data.frame(someList[[1]])
training_data <- as.data.frame(someList[[2]])
classes <- as.vector(someList[[3]])
cosineTop <- findSimUser(grouped_data,training_data, classes)
categories <- read.csv("Categories.csv",head=FALSE)
categories <- as.character(categories[,1])
again = 'y'

while(again != 'n'){
  cat("\nEnter user ID: ")
  userNum <- scan(what=numeric(),nmax=1,quiet=TRUE)
  
  #unreadable in one line but if you split this, then there will be gaps when its printed
  cat("\n1:  Shop & Service\n2: Outdoors & Recreation\n3: Residence \n4:	Professional & Other Places\n5: Food\n6: Travel & Transport \n7: Arts & Entertainment\n8: College & University\n9: Nightlife Spot\n10:	Athletic & Sport")
  cat("\nEnter category: ")
  category <- scan(what=numeric(),nmax=1,quiet=TRUE)
  category <- categories[category]
  unvisit <- recommend(userNum,originalData,cosineTop,frequencies,category)
  cat("Top suggestions:\n")
  for(i in 1:nrow(unvisit)){
    cat(i,"] ",as.character(unvisit[i,]$Var1),"\n",sep="")
  }
  
  cat("\nDo you wish to continue (y/n): ")
  again <- scan(what=character(),nmax=1,quiet=TRUE)
}

